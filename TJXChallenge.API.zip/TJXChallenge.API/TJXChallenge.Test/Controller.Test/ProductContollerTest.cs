﻿using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Xunit;
using TJXChallenge.API.Controllers;
using Microsoft.Extensions.Configuration;

namespace TJXChallenge.Test.Controller.Test
{
    public class ProductContollerTest
    {
        [Fact]
        public void ProductController_GetProducts_VallidateProductCount()
        {
            //Arrange
            string CountryCode = "USA";
            int productCount = 5;
            var product = new ProductController();
            //Act
            var productList = product.GetProducts(CountryCode);

            //Assert
            Assert.Equal(productCount,productList.Count());
        }
    }
}
